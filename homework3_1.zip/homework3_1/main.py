from datetime import datetime, timedelta
from collections import defaultdict
from menu import MENU
class Birthday:
    def __init__(self, string):
        try:
            self.date = datetime.strptime(string, '%d.%m.%Y')
        except ValueError:
            raise ValueError("Invalid date format. Please use DD.MM.YYYY.")

class Record:
    def __init__(self, name, phone, birthday=None):
        self.name = name
        self.phone = phone
        self.birthday = birthday

    def show_birthday(self):
        if self.birthday:
            return self.birthday.date.strftime('%d.%m.%Y')
        else:
            return "Birthday not set."

    def add_birthday(self, date_str):
        if not self.birthday:
            self.birthday = Birthday(date_str)
        else:
            raise ValueError("Birthday already set for this contact.")

class AddressBook:
    contacts = []

    def add_contact(self, record):
        self.contacts.append(record)

    def get_contact(self, name):
        for contact in self.contacts:
            if contact.name == name:
                return contact
        raise ValueError(f"Contact '{name}' not found.")

    def show_all_contacts(self):
        C = []
        for contact in self.contacts:
            info = (contact.name, contact.phone)
            if contact.birthday:
                info += (contact.birthday.date.strftime('%d.%m.%Y'),)
            C.append(info)
        return C
    def show_birthdays_this_week(self):
        birthdays_per_week = defaultdict(list)
        today = datetime.combine(datetime.today().date(), datetime.min.time())

        for contact in self.contacts:
            if contact.birthday:
                
                name = contact.name
                birthday_date = contact.birthday.date
                
                this_year = birthday_date.replace(year=today.year)

                if this_year < today:
                    this_year = this_year.replace(year=today.year + 1)

                delta_days = (this_year - today).days

                if delta_days < 7:
                    day_of_week = (today + timedelta(days=delta_days)).strftime("%A")
                    birthdays_per_week[day_of_week].append(name)
        
        for d, name in birthdays_per_week.items():
            print(f"{d}: {', '.join(name)}")
    def menu(self):
        return MENU 

class BOT:
    def __init__(self):
        self.address_book = AddressBook()

    def process_command(self, command):
        power = command.split()
        try:
            if power[0] == "add":
                self.address_book.add_contact(Record(power[1], power[2]))

            elif power[0] == "change":
                contact = self.address_book.get_contact(power[1])
                contact.phone = power[2]

            elif power[0] == "phone":
                return self.address_book.get_contact(power[1]).phone

            elif power[0] == "all":
                return self.address_book.show_all_contacts()

            elif power[0] == "contacts":
                return self.address_book.show_all_contacts()

            elif power[0] == "add-birthday":
                contact = self.address_book.get_contact(power[1])
                contact.add_birthday(power[2])

            elif power[0] == "show-birthday":
                return self.address_book.get_contact(power[1]).show_birthday()
            elif power[0] == 'birthdays':
                return self.address_book.show_birthdays_this_week() 
            elif power[0] == "hello":
                return "Hello! How can I assist you?"

            elif power[0] == "close" or power[0] == "exit":
                return "Good Job.Bye!!"
            
            elif power[0] == 'menu':
                return self.address_book.menu()

            else:
                return "Invalid command. Type 'menu' for see all commands."

        except ValueError as e:
            return str(e)
bot = BOT()
while True:
    command = input("Enter command: ")
    result = bot.process_command(command)
    
    if result:
        if isinstance(result, list):
            for item in result:
                print(item)
        else:
            print(result)

    if command.lower() in ["close", "exit"]:
        break
